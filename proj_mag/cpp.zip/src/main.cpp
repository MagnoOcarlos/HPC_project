#include<iostream>
#include<string>
#include<math.h>


using namespace std;

#include "Sphere.h"
#include "Geometry.h"

int main(){

	Geometry G(3.7,true);
	G.angularDistance();

	double u[3]={1,0,0};
	double v[3]={0,1,0};	

}
